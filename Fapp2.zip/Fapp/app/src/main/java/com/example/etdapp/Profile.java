package com.example.etdapp;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class Profile extends AppCompatActivity {

    private static final String DEBUGTAG="PROFILE";


    @Override
    protected void onResume() {
        super.onResume();
        Log.w(DEBUGTAG,"onResume");
        Wtask wstask = new Wtask();
        wstask.execute("http://belatar.name/tests/","profile.php?login=test&passwd=test");
    }
    class Wtask extends AsyncTask<String,Void,Etudiant>{

        @Override
        protected Etudiant doInBackground(String... strings) {
            Etudiant etd = null;
            try {

                URL url = new URL(strings[0]+strings[1]);
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                con.setRequestMethod("GET");
                InputStream in = con.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                String result="",ligne="";
                while ((ligne=reader.readLine())!=null){
                    result+= ligne;
                }
                con.disconnect();
                JSONObject json = new JSONObject(result);
                if(json.has("ERROR")){
                    Log.e(DEBUGTAG,json.getString("ERROR"));
                    //
                }
                else {
                    etd=new Etudiant(json.getInt("id"),json.getString("nom"),json.getString("prenom"),json.getString("phone"),json.getString("classe"));
                    url = new  URL(strings[0]+json.getString("photo"));
                    con = (HttpURLConnection) url.openConnection();
                    in = con.getInputStream();
                    etd.setImgae(BitmapFactory.decodeStream(in));
                    con.disconnect();
                }
                Log.d(DEBUGTAG,result);
            }catch(MalformedURLException e){
                e.printStackTrace();
            }
            catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return etd;
        }

        @Override
        protected void onPostExecute(Etudiant etudiant) {
            super.onPostExecute(etudiant);
            if(etudiant == null){

            }
            else {
                EditText nom =  findViewById(R.id.EtName);
                EditText prenom = findViewById(R.id.Etprenom);
                EditText classe= findViewById(R.id.Etemail);
                EditText remarks= findViewById(R.id.etremarks);
                ImageView photo = findViewById(R.id.img);
                nom.setText(etudiant.getNom());
                prenom.setText(etudiant.getPrenom());
                classe.setText(etudiant.getClasse());
                remarks.setText(etudiant.getTele());
                photo.setImageBitmap(etudiant.getImgae());
            }

        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

    }

    public void enregistrer(View view) {
        Toast.makeText(this,"Hello",Toast.LENGTH_LONG).show();
    }
}
